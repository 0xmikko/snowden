from unittest import TestCase


class TestChromeNativeApp(TestCase):
    def test_add_listener(self):
        self.fail()
